import { motion } from 'motion/react';

const experiences = [
  {
    company: 'TechFlow Systems',
    role: 'Senior Full Stack Engineer',
    period: '2023 — Present',
    description: 'Leading the development of a cloud-native analytics platform. Optimized database queries reducing latency by 40% and mentored junior developers.',
    technologies: ['React', 'Node.js', 'AWS', 'Kubernetes'],
  },
  {
    company: 'Digital Pulse Agency',
    role: 'Frontend Developer',
    period: '2021 — 2023',
    description: 'Crafted immersive web experiences for high-profile clients. Implemented complex animations and ensured cross-browser compatibility and performance.',
    technologies: ['Vue.js', 'GSAP', 'Tailwind CSS', 'Figma'],
  },
  {
    company: 'Innovate Labs',
    role: 'Junior Web Developer',
    period: '2019 — 2021',
    description: 'Collaborated on various internal tools and client projects. Focused on building responsive UI components and integrating RESTful APIs.',
    technologies: ['JavaScript', 'HTML/CSS', 'PHP', 'MySQL'],
  },
];

export default function Experience() {
  return (
    <section id="experience" className="section-padding bg-zinc-950/30">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <h2 className="text-sm font-semibold text-emerald-500 uppercase tracking-[0.3em] mb-4">Journey</h2>
            <h3 className="text-4xl md:text-6xl font-bold tracking-tighter">PROFESSIONAL EXPERIENCE</h3>
          </div>
          <p className="text-zinc-500 max-w-xs text-sm">
            A timeline of my professional growth and the impact I've made at various organizations.
          </p>
        </div>

        <div className="space-y-12">
          {experiences.map((exp, i) => (
            <motion.div
              key={exp.company}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="group relative grid grid-cols-1 md:grid-cols-4 gap-8 p-8 rounded-3xl border border-zinc-900 hover:border-emerald-500/30 hover:bg-zinc-900/20 transition-all"
            >
              <div className="md:col-span-1">
                <span className="text-sm font-medium text-zinc-500">{exp.period}</span>
              </div>
              
              <div className="md:col-span-3">
                <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 gap-2">
                  <h4 className="text-2xl font-bold group-hover:text-emerald-500 transition-colors">
                    {exp.role} <span className="text-zinc-600 font-normal">@</span> {exp.company}
                  </h4>
                </div>
                <p className="text-zinc-400 mb-6 leading-relaxed max-w-2xl">
                  {exp.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {exp.technologies.map((tech) => (
                    <span key={tech} className="text-[10px] px-2 py-1 rounded-md bg-zinc-900 text-zinc-500 border border-zinc-800">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
